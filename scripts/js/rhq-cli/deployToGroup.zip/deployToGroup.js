/*
 * deployToGroup.js
 * ----------------
 * The purpose of this script is to show how group deployment with JON 2.3 scripting 
 * works. This script was not tested very well and should not be used in productive 
 * environments without further testing. 
 *
 * As always: No warrenties and use it on your own risk
 *
 * @author: Wanja Pernath
 */

// set some defaults
var groupName = "ProductiveCluster"
var fileName;

// This should be calculated from the given file name or it could be a command line parameter
var packageName = "test.ear"


// check and parse parameters
if( args.length < 2) {
	usage();
}

fileName = args[0];
groupName = args[1];

// check to see if the file exists and is readable by us.
var file = new java.io.File(fileName);

if( !file.exists() ) {
	println(fileName + " does not exist!");
	usage();
}

if( !file.canRead() ) {
	println(fileName + " can't be read!");
	usage();
}

println("About to deploy " + fileName + " to group " + groupName );

// find resource group
var rgc = new ResourceGroupCriteria();
rgc.addFilterName(groupName);
rgc.fetchExplicitResources(true);
var groupList = ResourceGroupManager.findResourceGroupsByCriteria(rgc);

if( groupList == null || groupList.size() != 1 ) {
	println("Can't find a resource group named " + groupName);
	usage();
}

var group = groupList.get(0);	

println("  Found group: " + group.name );
println("  Group ID   : " + group.id );
println("  Description: " + group.description);

if( group.explicitResources == null || group.explicitResources.size() == 0 ) {
	println("  Group does not contain explicit resources --> exiting!" );
	usage();
}

var resourcesArray = group.explicitResources.toArray();

for( i in resourcesArray ) {
	var res = resourcesArray[i];
	var resType = res.resourceType.name;
	println("  Found resource " + res.name + " of type " + resType + " and ID " + res.id);
	
	if( resType != "JBossAS Server") {
		println("    ---> Resource not of required type. Exiting!");
		usage();
	}
	
	// get server resource to start/stop it and to redeploy application
	var server = ProxyFactory.getResource(res.id);
	
	var children = server.children;
	for( c in children ) {
		var child = children[c];
		
		if( child.name == packageName ) {
			println("    found child: " + child.name + " of ID " + child.id);
			
			println("    download old app to /tmp");
			child.retrieveBackingContent("/tmp/" + packageName + "_" + res.name + "_old");
			
			println("    stopping " + server.name + "....");
			try {
				server.shutdown();
			}
			catch( ex ) {
				println("   --> Caught " + ex );
			}

			
			println("    uploading new application code");
			child.updateBackingContent(fileName);
			
			println("    restarting " + server.name + "....." );

			try {
				server.start();
			}
			catch( ex ) {
				println("   --> Caught " + ex );
			}

			println("    done!");
		}

	}
}


function usage() {
	println("Usage: deployToGroup <fileName> <groupName>");
	throw "Illegal arguments";
}


